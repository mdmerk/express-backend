var express = require('express');
var router = express.Router();
var models = require('../models'); 
var authService = require('../services/auth');

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

//signup GET and Post

router.get('/signup', function (req, res, next) {
  res.render('signup')
});

router.post('/signup', function( req, res, next){
  models.users.findOrCreate({
    where:{ 
      UserName: req.body.username
    },
    defaults:{
      FirstName: req.body.firstname,
      LastName: req.body.lastname,
      Email: req.body.email,
      Password: authService.hashPassword(req.body.password)
    }
  }).spread(function(result, created){
    if (created){
      //res.send('User successfully created!');
      res.redirect('/users/login')
    }else {
      res.send('User already exists.');
    }
  });
});

//Login GET and POST
router.get('/login', function (req, res, next) {
  res.render('login');
});

router.post('/login', function(req, res, next){
  models.users.findOne({
    where: {
      UserName: req.body.username,
    }
  }).then( user =>{
    if(!user){
      console.log("User not found");
      return res.status(401).json({message:"Login Failed"});
    }else{
      let passwordMatch = authService.comparePasswords(req.body.password, user.Password);
      if (passwordMatch){
      let token = authService.signUser(user);
      res.cookie('jwt', token);
      //res.send('Login successful!');
      res.redirect('/users/profile')
      }else{
        console.log('Wrong password');
        res.send('Wrong password');
      }
     
    }
  })
});

//Profile GET

router.get('/profile', function(req, res, next){
  let token = req.cookies.jwt;
  authService.verifyUser(token).then(user => {
    if (user){
      user.Password = "";
      models.users.findOne({
        where: {
          UserName: user.UserName
        }, 
        include: [{
          model: models.posts,
          where: {Deleted: false},
          required: false
        }]
      }).then(usersInfo => {
        console.log(usersInfo.posts)
        res.render('profile', 
      {
        FirstName: usersInfo.FirstName,
        LastName: usersInfo.LastName,
        Email: usersInfo.Email,
        UserName: usersInfo.UserName,
        posts: usersInfo.posts
      });
      })
      
    }else {
      res.status(401);
      res.redirect('/users/accessdenied');
    }
  });
}); 


//Admin users/admin: view all users page
router.get('/admin', function(req, res, next){
  let token = req.cookies.jwt;
  authService.verifyUser(token).then(user => {
  if(user && user.Admin){
    models.users
    .findAll({
      where:{
        Deleted: false
      }
    })
    .then(users =>{
      if (users){
        res.render('allusers', {
          allUsers: users
        });
      } else{
        res.send('Users not found')
      }
    });
  }else{
    res.redirect('/users/unauthorized')
  }
});
});

//Admin specific user page (users/admin/editusers/:id)
router.get('/admin/editusers/:id', function(req, res, next){
  let token = req.cookies.jwt;
  authService.verifyUser(token).then(user => {
  if(user && user.Admin){
    models.users
    .findOne({
      where:{UserId: parseInt(req.params.id)},
      include: [{
        model: models.posts,
        where: {Deleted: false},
        required: false
      }]
    })
    .then(usersInfo => {
      console.log(usersInfo.posts)
      res.render('oneuser', 
    {
      FirstName: usersInfo.FirstName,
      LastName: usersInfo.LastName,
      Email: usersInfo.Email,
      UserName: usersInfo.UserName,
      UserId: usersInfo.UserId,
      posts: usersInfo.posts
    });
    })
  }else{
    res.redirect('/users/unauthorized')
  }
});
  
});

//Admin delete users
router.post('/admin/deleteuser/:id', function (req, res, next) {
  let token = req.cookies.jwt;
  authService.verifyUser(token).then(user => {
  if(user && user.Admin){
    const id  = req.params.id;
    console.log(id)
     models.users.update({
        Deleted: true
     }, {
       where: {
         UserId: id
       }
     }
     ).then(response => {
       res.redirect('/users/admin')
     })
  } else{
    res.redirect('/users/unauthorized')
  }
});

});
//Admin delete posts
router.post('/admin/editusers/deleteposts/:id', function (req, res, next) {
  let token = req.cookies.jwt;
  authService.verifyUser(token).then(user => {
  if(user && user.Admin){
  models.posts;
  const id  = req.params.id;
  console.log(id)
   models.posts.update({
      Deleted: true
   }, {
     where: {
       PostId: id
     }
   }
   ).then(response => {
     res.redirect('/users/admin')
   })
  } else{
    res.redirect('/users/accessdenied');
    
  }
});

});



//Logout 
router.get('/logout', function(req, res, next){
  res.cookie('jwt', "", {expires: new Date(0)});
  res.redirect('/');
});


//post stuff below
//view all posts
router.get('/profile/posts', function(req, res, next){
  let token = req.cookies.jwt;
  authService.verifyUser(token).then(user =>{
    if(user){
    models.posts
    .findAll({
      where:{
        Deleted: false,
        UserId: user.UserId
      }
    })
    .then(posts =>{
      if (posts){
        res.render('allposts', {
          allPosts: posts
        });
      } else{
        res.send('Users not found')
      }
    });
  }else{
    res.redirect('/users/unauthorized')
  }
  })
})

//make post
router.post('/profile/posts/createpost', function(req, res, next){
  let token = req.cookies.jwt;
  authService.verifyUser(token).then(user => {
  if (user){
    models.posts.findOrCreate({
      where:{
        PostTitle: req.body.PostTitle
      },
      defaults: {
        PostBody: req.body.PostBody,
        UserId: user.UserId
      }
    })
    .spread(function(result, created){
      if(created){
        res.redirect('/users/profile/posts');
      }else{
        res.redirect('/users/profile')
        console.log('Post Failed');
      }
    });
  }else {
    res.status(401);
    res.send("You must be logged in")
  }
});
});
//edit post page
router.get('/profile/posts/:id', function(req, res, next){
  let token = req.cookies.jwt;
  authService.verifyUser(token).then(user => {
  if(user){
    models.posts
    .findOne({
      where:{PostId: parseInt(req.params.id),},
      
    })
    .then(posts => {
      res.render('onepost', 
    {
      PostTitle: posts.PostTitle,
      PostBody: posts.PostBody,
      PostId: posts.PostId
    });
    })
  }else{
    res.redirect('/users/accessdenied')
  }
});
  
});
//edit post
router.post('/profile/posts/editposts/:id', function(req, res, next){
  let postId = req.params.id;
  let token = req.cookies.jwt;
  authService.verifyUser(token).then(user => {
  if (user){
    models.posts.update({
        PostTitle: req.body.PostTitle,
        PostBody: req.body.PostBody,
      }, {
      where:{
        PostId: postId,
      }
    })
    .then(result => {
      res.redirect('/users/profile/posts');
    });
  }else {
    res.status(401);
    res.send("You must be logged in")
  }
});
});
//delete post
router.post('/profile/delete/posts/:id', function (req, res, next) {
  let token = req.cookies.jwt;
  authService.verifyUser(token).then(user => {
  if(user){
  models.posts;
  const id  = req.params.id;
  console.log(id)
   models.posts.update({
      Deleted: true
   }, {
     where: {
       PostId: id
     }
   }
   ).then(response => {
     res.redirect('/users/profile/posts')
   })
  } else{
    res.redirect('/users/accessdenied');
    
  }
});

});

//unauthorized
router.get('/unauthorized', function(req, res, next){
  let token = req.cookies.jwt;
  authService.verifyUser(token).then(user => {
  res.render('unauthorized')
  });
});

//not logged in
router.get('/accessdenied', function(req, res, next){
  res.render('accessdenied')
})


module.exports = router;
